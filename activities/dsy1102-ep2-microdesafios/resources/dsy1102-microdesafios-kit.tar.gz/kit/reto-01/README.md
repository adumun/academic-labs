# Mi primera ventana funcional — Reto 01

**Tiempo objetivo:** 20 minutos.

**Arranque:** abrir esta carpeta como proyecto Maven en IntelliJ IDEA, seleccionar Java 21 y ejecutar `Launcher`. También puede usarse `mvn javafx:run` cuando Maven esté disponible.

## Tu misión
1. Crear `controller/RecepcionController.java` y asociarlo a `main-view.fxml` mediante `fx:controller`.
2. Vincular `txtNombre` y `lblMensaje` mediante `@FXML`.
3. Conectar el botón «Saludar» a un método del controlador.
4. Si el texto está vacío o solo tiene espacios, mostrar `Ingresa un nombre válido.` sin borrar el campo.
5. Si es válido, mostrar `Recepción registrada: NOMBRE` y limpiar el campo. No usar `System.out.println`.

**Pruebas:** `Ana` → mensaje correcto; `   ` → mensaje de error y texto conservado.

**Regla:** no modificar `App`, `Launcher` ni las reglas del modelo `Articulo`; trabajar sobre la vista, controlador o repository señalado. No se requieren bases de datos ni internet durante el ejercicio si las dependencias ya están disponibles.
