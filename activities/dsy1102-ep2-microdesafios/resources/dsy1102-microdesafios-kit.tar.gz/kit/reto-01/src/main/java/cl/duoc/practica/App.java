package cl.duoc.practica;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.stage.Stage;
public class App extends Application {
    @Override public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/cl/duoc/practica/view/main-view.fxml"));
        stage.setScene(new Scene(root, 680, 430));
        stage.setTitle("DSY1102 - Microdesafío");
        stage.show();
    }
}
