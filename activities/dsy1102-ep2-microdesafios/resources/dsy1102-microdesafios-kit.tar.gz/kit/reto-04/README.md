# Selecciona y elimina — Reto 04

**Tiempo objetivo:** 20 minutos.

**Arranque:** abrir esta carpeta como proyecto Maven en IntelliJ IDEA, seleccionar Java 21 y ejecutar `Launcher`. También puede usarse `mvn javafx:run` cuando Maven esté disponible.

## Tu misión
La tabla ya contiene tres artículos. Implementar exclusivamente `onEliminar`. Si no hay fila seleccionada, informar `Debes seleccionar un artículo.` y no eliminar nada. Con una fila seleccionada, eliminar esa misma instancia de la lista y mostrar `ART-02 eliminado correctamente.` (cambiando el código según la selección). No imprimir mensajes por consola.

**Pruebas:** Eliminar sin selección → tres filas; seleccionar `ART-02` y eliminar → quedan `ART-01` y `ART-03`.

**Regla:** no modificar `App`, `Launcher` ni las reglas del modelo `Articulo`; trabajar sobre la vista, controlador o repository señalado. No se requieren bases de datos ni internet durante el ejercicio si las dependencias ya están disponibles.
