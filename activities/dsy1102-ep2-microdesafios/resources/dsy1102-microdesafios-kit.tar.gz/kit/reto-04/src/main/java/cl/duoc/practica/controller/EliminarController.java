package cl.duoc.practica.controller;
import cl.duoc.practica.model.Articulo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
public class EliminarController {
    @FXML private TableView<Articulo> tabla;
    @FXML private TableColumn<Articulo, String> colCodigo;
    @FXML private TableColumn<Articulo, Integer> colCantidad;
    @FXML private Label lblMensaje;
    private final ObservableList<Articulo> articulos = FXCollections.observableArrayList(
        new Articulo("ART-01", 2, 2500),
        new Articulo("ART-02", 1, 8900),
        new Articulo("ART-03", 4, 1200)
    );
    @FXML private void initialize() {
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        tabla.setItems(articulos);
    }
    @FXML private void onEliminar() {
        // TODO: validar selección, eliminar solo esa fila y mostrar mensaje dentro de la ventana.
        lblMensaje.setText("Eliminación pendiente de implementar.");
    }
}
