package cl.duoc.practica.repository;
import cl.duoc.practica.model.Articulo;
import java.io.IOException;
import java.util.List;
public class ArticuloRepository {
    public List<Articulo> cargar() throws IOException {
        // TODO: leer articulos.json con Gson y reconstruir una List<Articulo>.
        // Si NO existe, devolver lista vacía sin lanzar excepción.
        // Si el contenido es ilegible o inválido, informar mediante IOException.
        return List.of();
    }
}
