package cl.duoc.practica.controller;
import cl.duoc.practica.model.Articulo;
import cl.duoc.practica.repository.ArticuloRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.IOException;
public class CargarController {
    @FXML private TableView<Articulo> tabla;
    @FXML private TableColumn<Articulo, String> colCodigo;
    @FXML private TableColumn<Articulo, Integer> colCantidad;
    @FXML private Label lblMensaje;
    private final ObservableList<Articulo> articulos = FXCollections.observableArrayList();
    private final ArticuloRepository repository = new ArticuloRepository();
    @FXML private void initialize() {
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        tabla.setItems(articulos);
        onRecargar();
    }
    @FXML private void onRecargar() {
        try {
            articulos.setAll(repository.cargar());
            lblMensaje.setText(articulos.isEmpty() ? "No hay artículos registrados." : "Artículos recuperados: " + articulos.size());
        } catch (IOException e) {
            lblMensaje.setText("Error al leer archivo: " + e.getMessage());
        }
    }
}
