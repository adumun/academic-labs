# Recuperación de información — Reto 06

**Tiempo objetivo:** 30 minutos.

**Arranque:** abrir esta carpeta como proyecto Maven en IntelliJ IDEA, seleccionar Java 21 y ejecutar `Launcher`. También puede usarse `mvn javafx:run` cuando Maven esté disponible.

## Tu misión
Implementar únicamente `ArticuloRepository.cargar()`. Usar Gson y, si hace falta, `TypeToken` para reconstruir correctamente una `List<Articulo>` desde `articulos.json`. El controlador ya carga la lista al iniciar y puede recargarla mediante el botón. Si el archivo no existe, devolver una lista vacía sin error; si el archivo es inválido, mostrar el error en la interfaz por medio de `IOException`. No modificar el modelo ni la vista.

**Pruebas:** con el archivo entregado deben verse tres registros (`ART-10`, `ART-11`, `ART-12`); si se renombra el archivo, la tabla inicia vacía y sin error; si contiene JSON inválido, aparece el error en la etiqueta sin cerrar la ventana.

**Regla:** no modificar `App`, `Launcher` ni las reglas del modelo `Articulo`; trabajar sobre la vista, controlador o repository señalado. No se requieren bases de datos ni internet durante el ejercicio si las dependencias ya están disponibles.
