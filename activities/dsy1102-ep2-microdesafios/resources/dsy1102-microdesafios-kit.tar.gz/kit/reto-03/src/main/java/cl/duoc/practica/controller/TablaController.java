package cl.duoc.practica.controller;
import cl.duoc.practica.model.Articulo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
public class TablaController {
    @FXML private TextField txtCodigo, txtCantidad, txtPrecio;
    @FXML private Label lblMensaje;
    @FXML private TableView<Articulo> tabla;
    @FXML private TableColumn<Articulo, String> colCodigo;
    @FXML private TableColumn<Articulo, Integer> colCantidad;
    @FXML private TableColumn<Articulo, Double> colTotal;
    private final ObservableList<Articulo> articulos = FXCollections.observableArrayList();
    @FXML private void initialize() {
        // TODO: configurar las tres columnas con getters del modelo.
        // TODO: enlazar tabla con la lista observable.
    }
    @FXML private void onRegistrar() {
        // TODO: validar/convertir, construir Articulo, agregarlo a la lista y mostrar mensaje.
        lblMensaje.setText("Registro pendiente de implementar.");
    }
}
