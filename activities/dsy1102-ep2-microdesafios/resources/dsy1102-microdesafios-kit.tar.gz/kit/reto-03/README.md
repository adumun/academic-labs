# Del formulario a la tabla — Reto 03

**Tiempo objetivo:** 30 minutos.

**Arranque:** abrir esta carpeta como proyecto Maven en IntelliJ IDEA, seleccionar Java 21 y ejecutar `Launcher`. También puede usarse `mvn javafx:run` cuando Maven esté disponible.

## Tu misión
Completar `initialize()` y `onRegistrar()` en `TablaController`. La `ObservableList` ya está creada. Las columnas deben mostrar código, cantidad y `getTotal()` del modelo; usar los nombres de propiedades adecuados. Al registrar, debe aparecer una fila inmediatamente, sin recargar la ventana. Mostrar mensajes en la etiqueta ante un error, sin cerrar la aplicación.

**Pruebas:** `ART-01`, `3`, `1200` → total `3600`; `ART-02`, `1`, `900` → total `900`; deben verse dos filas distintas.

**Regla:** no modificar `App`, `Launcher` ni las reglas del modelo `Articulo`; trabajar sobre la vista, controlador o repository señalado. No se requieren bases de datos ni internet durante el ejercicio si las dependencias ya están disponibles.
