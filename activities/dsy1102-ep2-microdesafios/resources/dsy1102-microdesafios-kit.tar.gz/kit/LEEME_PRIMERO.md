# DSY1102 — Kit de práctica EP2

Seis proyectos Maven independientes, uno por microdesafío. Todos están preparados para Java 21 + JavaFX 21.0.6, y los retos 05/06 incluyen la dependencia Gson 2.11.0.

1. Elige un reto. No es necesario resolver los anteriores.
2. Abre la carpeta `reto-XX` como proyecto Maven en IntelliJ IDEA.
3. Usa JDK 21 y ejecuta la clase `cl.duoc.practica.Launcher`.
4. Lee `README.md` dentro del reto. El código contiene comentarios `TODO`.
5. Realiza únicamente los cambios pedidos; guarda evidencias de la ventana y el archivo JSON cuando aplique.

**Advertencia:** los retos 01 y 05/06 contienen funcionalidad faltante a propósito: en 01 el botón aún no hace nada; en 05/06 falta guardar/leer. Están diseñados para abrir y mostrar la ventana antes de implementar.

**Material preparatorio distinto de las formas oficiales D/E/F**: usa la entidad Articulo para practicar sin resolver los casos específicos de la prueba.
