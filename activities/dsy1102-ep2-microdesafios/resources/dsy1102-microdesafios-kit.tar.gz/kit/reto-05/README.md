# Los datos sobreviven al cierre — Reto 05

**Tiempo objetivo:** 30 minutos.

**Arranque:** abrir esta carpeta como proyecto Maven en IntelliJ IDEA, seleccionar Java 21 y ejecutar `Launcher`. También puede usarse `mvn javafx:run` cuando Maven esté disponible.

## Tu misión
Implementar únicamente `ArticuloRepository.guardar(List<Articulo>)`. La interfaz y el controlador ya funcionan: el controlador llama al repository y maneja `IOException`. Usar Gson para generar un archivo JSON en la raíz del proyecto llamado `articulos.json`. El contenido debe corresponder a los dos artículos ya cargados, sin imprimir resultados por consola.

**Pruebas:** antes de guardar no existe el archivo; al pulsar Guardar, aparece la confirmación y se crea un JSON válido con `ART-01` y `ART-02` y todos sus datos. No modificar la vista.

**Regla:** no modificar `App`, `Launcher` ni las reglas del modelo `Articulo`; trabajar sobre la vista, controlador o repository señalado. No se requieren bases de datos ni internet durante el ejercicio si las dependencias ya están disponibles.
