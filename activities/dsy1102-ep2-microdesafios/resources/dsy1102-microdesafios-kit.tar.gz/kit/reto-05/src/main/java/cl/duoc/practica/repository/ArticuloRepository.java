package cl.duoc.practica.repository;
import cl.duoc.practica.model.Articulo;
import java.io.IOException;
import java.util.List;
public class ArticuloRepository {
    public void guardar(List<Articulo> articulos) throws IOException {
        // TODO: serializar la lista con Gson y escribir el JSON UTF-8
        // en el archivo articulos.json de la raíz del proyecto.
        throw new IOException("Método guardar aún no implementado.");
    }
}
