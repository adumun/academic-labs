package cl.duoc.practica.controller;
import cl.duoc.practica.model.Articulo;
import cl.duoc.practica.repository.ArticuloRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.IOException;
public class GuardarController {
    @FXML private TableView<Articulo> tabla;
    @FXML private TableColumn<Articulo, String> colCodigo;
    @FXML private TableColumn<Articulo, Integer> colCantidad;
    @FXML private Label lblMensaje;
    private final ObservableList<Articulo> articulos = FXCollections.observableArrayList(
        new Articulo("ART-01", 2, 2500),
        new Articulo("ART-02", 1, 8900)
    );
    private final ArticuloRepository repository = new ArticuloRepository();
    @FXML private void initialize() {
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        tabla.setItems(articulos);
    }
    @FXML private void onGuardar() {
        try {
            repository.guardar(articulos);
            lblMensaje.setText("Inventario guardado correctamente.");
        } catch (IOException e) {
            lblMensaje.setText("Error al guardar: " + e.getMessage());
        }
    }
}
