# El formulario no acepta cualquier cosa — Reto 02

**Tiempo objetivo:** 25 minutos.

**Arranque:** abrir esta carpeta como proyecto Maven en IntelliJ IDEA, seleccionar Java 21 y ejecutar `Launcher`. También puede usarse `mvn javafx:run` cuando Maven esté disponible.

## Tu misión
El botón ya está conectado y el modelo `Articulo` ya valida sus atributos. Completar `onRegistrar` para convertir los datos a tipos numéricos, crear el objeto y mostrar `ART-001 registrado. Total: $7000.0` al ingresar código `ART-001`, cantidad `2`, precio `3500`. Si un valor es inválido, mostrar en la etiqueta qué ocurrió y conservar todos los datos ingresados. No registrar nada ni limpiar datos ante un error.

**Pruebas:** cantidad `0` → mensaje de negocio; `abc` → mensaje de formato; código en blanco → error; entrada válida → confirmación y campos limpios.

**Regla:** no modificar `App`, `Launcher` ni las reglas del modelo `Articulo`; trabajar sobre la vista, controlador o repository señalado. No se requieren bases de datos ni internet durante el ejercicio si las dependencias ya están disponibles.
