package cl.duoc.practica.controller;
import cl.duoc.practica.model.Articulo;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
public class RegistroController {
    @FXML private TextField txtCodigo;
    @FXML private TextField txtCantidad;
    @FXML private TextField txtPrecio;
    @FXML private Label lblMensaje;
    @FXML private void onRegistrar() {
        // TODO: interpretar los campos, construir Articulo y mostrar el total.
        // TODO: capturar errores de formato/negocio y conservar los campos ante errores.
        // TODO: limpiar campos SOLO si el registro fue válido.
        lblMensaje.setText("Registro pendiente de implementar.");
    }
}
