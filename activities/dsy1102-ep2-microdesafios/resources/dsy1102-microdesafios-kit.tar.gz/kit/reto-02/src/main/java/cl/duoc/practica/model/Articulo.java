package cl.duoc.practica.model;
/** Modelo entregado: no modificar sus reglas de negocio. */
public class Articulo {
    private String codigo;
    private int cantidad;
    private double precioUnitario;
    public Articulo() { }
    public Articulo(String codigo, int cantidad, double precioUnitario) {
        setCodigo(codigo);
        setCantidad(cantidad);
        setPrecioUnitario(precioUnitario);
    }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código es obligatorio.");
        }
        this.codigo = codigo.trim();
    }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) {
        if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        this.cantidad = cantidad;
    }
    public double getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(double precioUnitario) {
        if (!Double.isFinite(precioUnitario) || precioUnitario <= 0) {
            throw new IllegalArgumentException("El precio debe ser un número positivo.");
        }
        this.precioUnitario = precioUnitario;
    }
    public double getTotal() { return cantidad * precioUnitario; }
}
