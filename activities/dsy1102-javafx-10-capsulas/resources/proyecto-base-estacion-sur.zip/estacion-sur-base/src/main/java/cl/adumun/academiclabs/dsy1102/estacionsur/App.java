package cl.adumun.academiclabs.dsy1102.estacionsur;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/** Punto de entrada. La vista final será desarrollada por el estudiante. */
public class App extends Application {

    @Override
    public void start(Stage stage) {
        Label titulo = new Label("Centro Cultural Estación Sur");
        titulo.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        Label mensaje = new Label("Proyecto base listo. Continúa con las cápsulas de Academic Labs.");
        VBox root = new VBox(18, titulo, mensaje);
        root.setPadding(new Insets(28));
        root.setAlignment(Pos.CENTER);

        stage.setTitle("Centro Cultural Estación Sur — base");
        stage.setScene(new Scene(root, 900, 560));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
