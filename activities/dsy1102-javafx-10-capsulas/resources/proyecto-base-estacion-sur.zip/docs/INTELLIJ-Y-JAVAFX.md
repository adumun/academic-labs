# Ejecutar el proyecto JavaFX desde IntelliJ IDEA

Este proyecto utiliza **Java 21, Maven y JavaFX 21**. JavaFX no viene incluido en el JDK desde Java 11; por eso, tener Java 21 instalado no basta para ejecutar la clase principal directamente.

## Abrir el proyecto

1. Descomprime el ZIP.
2. En IntelliJ IDEA selecciona **File → Open** y abre la carpeta que contiene `pom.xml`.
3. Si IntelliJ pregunta cómo abrir el proyecto, acepta la importación como proyecto Maven.
4. Configura **Project SDK: JDK 21** en **File → Project Structure → Project**.
5. Espera a que Maven termine de importar y descargar las dependencias.

## Ejecutar JavaFX

**No ejecutes `App.java` directamente con una configuración Application.** Esa modalidad puede mostrar:

`Error: JavaFX runtime components are missing, and are required to run this application`

La clase puede compilar, pero la ejecución directa no incorpora automáticamente los módulos y bibliotecas nativas de JavaFX.

Este proyecto incluye una configuración compartida de IntelliJ:

- Selecciona **JavaFX - Ejecutar aplicación** en el selector de configuraciones, junto al botón verde.
- Pulsa **Run**.

La configuración ejecuta el objetivo Maven `javafx:run` desde la raíz del proyecto y utiliza el JDK del proyecto.

### Si la configuración no aparece

1. Abre **View → Tool Windows → Maven**.
2. Pulsa **Reload All Maven Projects**.
3. Expande el proyecto y luego **Plugins → javafx**.
4. Ejecuta **javafx:run**.

También puedes abrir la terminal integrada en la raíz del proyecto y ejecutar:

```bash
mvn javafx:run
```

## Ejecutar las pruebas

Desde la ventana Maven, abre **Lifecycle → test**, o ejecuta:

```bash
mvn test
```

Para limpiar y ejecutar todas las pruebas:

```bash
mvn clean test
```

## Windows y WSL2

### Windows

- Utiliza un JDK 21 instalado en Windows.
- En **Settings → Build, Execution, Deployment → Build Tools → Maven → Runner**, selecciona **JRE: Project JDK**.
- Ejecuta el objetivo Maven `javafx:run`; Maven descargará las dependencias correspondientes a Windows.

### WSL2 (Ubuntu)

- Mantén el proyecto dentro del filesystem Linux, por ejemplo `~/projects/estacion-sur-base`, en lugar de trabajar desde `/mnt/c`.
- Instala JDK 21 y Maven dentro de WSL2: `sudo apt install openjdk-21-jdk maven`.
- Abre el proyecto mediante la integración WSL de IntelliJ y asegúrate de que el Maven Runner use el JDK 21 de Linux, no el JDK de Windows.
- Ejecuta `mvn javafx:run` desde el entorno WSL. Para mostrar la ventana gráfica necesitas WSLg operativo.

**Importante:** no mezcles un Maven/JDK de Windows con un proyecto que se ejecuta en WSL2, ni al revés. JavaFX incluye bibliotecas nativas específicas de cada sistema operativo.

## Qué significa el error de runtime

Si aparece el mensaje de que faltan los componentes JavaFX, revisa primero cómo se está ejecutando la aplicación. En este proyecto, la vía soportada es Maven `javafx:run`; no es necesario añadir manualmente un JavaFX SDK al JDK ni copiar módulos a la carpeta del proyecto.
